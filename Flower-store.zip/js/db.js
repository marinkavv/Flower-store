const products = [
  {
    image: "/Images/bouquet_cart11.png",
    alt: "троянди та лілії",
    name: "Ніжна свіжість",
    description: "троянди та лілії",
    price: 445,
  },
  {
    image: "/Images/bouquet_cart21.png",
    alt: "хризантеми та троянди",
    name: "Сорбет",
    description: "хризантеми та троянди",
    price: 450,
  },
  {
    image: "/Images/bouquet_cart31.png",
    alt: "соняшники та солідаго",
    name: "Yellow Song",
    description: "соняшники та солідаго",
    price: 455,
  },
  {
    image: "/Images/bouquet_cart41.png",
    alt: "лілії та троянди",
    name: "Персиковий нектар",
    description: "лілії та троянди",
    price: 455,
  },
  {
    image: "/Images/bouquet_cart51.png",
    alt: "лілії та троянди",
    name: "Аврора",
    description: "лілії та троянди",
    price: 460,
  },
  {
    image: "/Images/bouquet_cart61.png",
    alt: "червоні троянди",
    name: "Класика кохання",
    description: "червоні троянди",
    price: 465,
  },
];
